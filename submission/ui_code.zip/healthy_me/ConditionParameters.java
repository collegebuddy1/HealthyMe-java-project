package healthy_me;

/**
 * Created by jugal on 7/30/2016.
 */
public class ConditionParameters {
    private String _first_name;
    private String _last_name;
    private String _date_x;
    private String _date_y;

    public String get_first_name() {
        return _first_name;
    }

    public void set_first_name(String _first_name) {
        this._first_name = _first_name;
    }

    public String get_last_name() {
        return _last_name;
    }

    public void set_last_name(String _last_name) {
        this._last_name = _last_name;
    }

    public String get_date_x() {
        return _date_x;
    }

    public void set_date_x(String _date_x) {
        this._date_x = _date_x;
    }

    public String get_date_y() {
        return _date_y;
    }

    public void set_date_y(String _date_y) {
        this._date_y = _date_y;
    }
}
